class Foo_Test:
    
    def test_foo(self):
        pass

    def test_bar(self):
        pass
