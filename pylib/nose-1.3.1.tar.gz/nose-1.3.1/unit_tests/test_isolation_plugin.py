def test_lint():
    import nose.plugins.isolate
