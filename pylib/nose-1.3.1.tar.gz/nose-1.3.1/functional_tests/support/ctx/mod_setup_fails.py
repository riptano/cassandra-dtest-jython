def setup():
    assert False, "Failure in mod setup"


def test_a():
    raise AssertionError("test_a should not run")


def test_b():
    raise AssertionError("test_b should not run")


