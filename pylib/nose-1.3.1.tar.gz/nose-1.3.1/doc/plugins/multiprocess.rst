------------------------------
Multiprocess: parallel testing
------------------------------

.. autoplugin :: nose.plugins.multiprocess
