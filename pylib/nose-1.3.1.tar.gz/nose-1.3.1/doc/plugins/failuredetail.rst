Failure Detail: introspect asserts
==================================

.. autoplugin :: nose.plugins.failuredetail
