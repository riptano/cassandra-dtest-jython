Debug: drop into pdb on errors or failures
==========================================

.. autoplugin :: nose.plugins.debug